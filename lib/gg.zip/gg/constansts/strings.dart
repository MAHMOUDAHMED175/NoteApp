import 'package:flutter/material.dart';

const String homepage = '/';
const String charcter_details = '/character_details';
final String baseurl = 'https://rickandmortyapi.com/api/';
final TextEditingController textSearchController = TextEditingController();
