import 'dart:ui';

class MyColors {
  static const Color myyello = Color(0xffc107);
  static const Color mygrey = Color(0xff343A40);
  static const Color mywhite = Color(0xffE1E8EB);
}
